import { Router } from "express";
import {
  deleteUser,
  getCurrentUser,
  getUserById,
  getUsers,
  loginUser,
  logoutUser,
  registerUser,
  sendSignupOTP,
  updateUser,
  verifySignupOTP,
  sendResetPasswordOTP,
  verifyResetPasswordOTP,
  resetPassward,
} from "../controller/user.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorizeRoles } from "../middlewares/authorizeRoles.middleware.js";
import { upload } from "../middlewares/multer.middleware.js";

const router = Router();

router.route("/register").post(upload.single("profileImage"), registerUser);
router.route("/login").post(loginUser);
router.route("/logout").post(logoutUser);
  
//secured routes
router.route("/current-user").get(authenticate, getCurrentUser);
router.route("/all-users").get(getUsers);
router.route("/user/:userId").get(getUserById);
router
  .route("/delete-user/:userId")
  .delete(authenticate, authorizeRoles("ADMIN", "SUB_ADMIN"), deleteUser);

router
  .route("/update")
  .put(authenticate, upload.single("profileImage"), updateUser);

//signup otp route
router.route("/signup-otp").post(sendSignupOTP);
router.route("/verify-signup-otp").post(verifySignupOTP);
router.route("/reset-password-otp").post(sendResetPasswordOTP);
router.route("/verify-reset-password-otp").post(verifyResetPasswordOTP);
router.route("/reset-password").post(resetPassward);

export default router;
