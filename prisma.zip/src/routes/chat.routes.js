import { Router } from "express";
import {
  createRoom,
  getMyRooms,
  getMessages,
  markMessageRead,
  addMembersToRoom,
  removeMemberFromRoom,
  getRoomDetails
} from "../controller/chat.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

// All routes are protected
router.use(authenticate);

// Create a new chat room
router.post("/create-room", createRoom);

// Get all rooms for current logged-in user
router.get("/my-rooms", getMyRooms);

// Get all messages in a specific room
router.get("/messages/:roomId", getMessages);


// Add members to room (group only)
router.put("/add-members/:roomId", addMembersToRoom);

// Remove members from room (group only)
router.put("/remove-members/:roomId", removeMemberFromRoom);

// Get room details
router.get("/room/:roomId", getRoomDetails);

export default router;
