import nodemailer from "nodemailer";
import dotenv from "dotenv";
import { emailTemplates } from "./emailTemplates.js";

dotenv.config();
const transporter = nodemailer.createTransport({
  service: "gmail",

  auth: {
    user: `${process.env.EMAIL}`,
    pass: `${process.env.PASSWORD}`,
  },
});

export const sendEmail = async ({ to, subject, data, template }) => {
  try {
    console.log("Sending email to:", to);
    // Validate required fields
    if (!to || !subject || !template) {
      throw new Error("Missing required email parameters");
    }

    // Check if template exists
    if (!emailTemplates[template]) {
      throw new Error(`Template '${template}' not found`);
    }

    const mailOptions = {
      from: process.env.EMAIL,
      to,
      subject,
      html: emailTemplates[template](data),
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent:", info.response);
    return info;
  } catch (error) {
    console.error("Error sending email:", error.message);
    throw error;
  }
};
