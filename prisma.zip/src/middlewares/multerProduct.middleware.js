import multer from "multer";

// Storage Configuration for Product Images
const productStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./public/temp");
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

// File Filter for Product Images
const productFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Only JPG, PNG, and WebP images are allowed!"), false);
  }
};

// Multer Configuration
export const uploadProduct = multer({
  storage: productStorage,
  fileFilter: productFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // Limit to 5MB
});
