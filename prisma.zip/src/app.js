import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import http from "http";
import session from "express-session";
import passport from "passport";
import { Server } from "socket.io";
import prisma from "./prisma.js";

const app = express();
const server = http.createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
  cors: {
    origin: [process.env.CORS_ORIGIN, process.env.CORS_ORIGIN_ADMIN],
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE"],
  },
});

// Track online users
let onlineUsers = {};

// Socket.IO logic
io.on("connection", (socket) => {
  const userId = socket.handshake.query.userId;
  if (!userId) return;

  onlineUsers[userId] = socket.id;
  console.log(`User ${userId} connected`);

  // Notify others that the user is online
  io.emit("user-status", { userId, status: "online" });

  socket.on("join-room", (roomId) => {
    socket.join(roomId);
    console.log(`User ${userId} joined room ${roomId}`);
  });

  socket.on("leave-room", (roomId) => {
    socket.leave(roomId);
    console.log(`User ${userId} left room ${roomId}`);
  });

  socket.on("send-message", async (messageData) => {
    try {
      const { roomId, content, type = "TEXT" } = messageData;

      // 1️⃣ Create message in DB
      const message = await prisma.message.create({
        data: {
          roomId,
          senderId: userId,
          content,
          type,
        },
        include: { sender: true }, // include sender info
      });

      // 2️⃣ Get all room members
      const members = await prisma.chatMember.findMany({
        where: { roomId },
        select: { userId: true },
      });

      // 3️⃣ Create message status for each member
      const statusesData = members.map((member) => ({
        messageId: message.id,
        userId: member.userId,
        status: member.userId === userId ? "READ" : "SENT", // sender sees READ
        readAt: member.userId === userId ? new Date() : null,
      }));
      await prisma.messageStatus.createMany({ data: statusesData });

      // 4️⃣ Attach statuses to message for frontend
      const messageWithStatuses = {
        ...message,
        statuses: statusesData,
      };

      // 5️⃣ Emit message to all room members
      io.to(roomId).emit("new-message", messageWithStatuses);

    } catch (error) {
      console.error("Error sending message:", error);
    }
  });

  // Mark messages as read
  socket.on("mark-read", async ({ roomId, messageIds }) => {
    try {
      // Update MessageStatus for the current user
      await prisma.messageStatus.updateMany({
        where: {
          messageId: { in: messageIds },
          userId: userId,
        },
        data: {
          status: "READ",
          readAt: new Date(),
        },
      });

      // Notify all users in the room about the updated statuses
      const updatedStatuses = await prisma.messageStatus.findMany({
        where: {
          messageId: { in: messageIds },
        },
      });

      io.to(roomId).emit("messages-read", updatedStatuses);
    } catch (err) {
      console.error("Error marking messages as read:", err);
    }
  });


  socket.on("disconnect", () => {
    delete onlineUsers[userId];
    io.emit("user-status", { userId, status: "offline" });
    console.log(`User ${userId} disconnected`);
  });
});

// Middleware
app.use(morgan("dev"));
app.use(cors({
  origin: [process.env.CORS_ORIGIN, process.env.CORS_ORIGIN_ADMIN],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Use proper session secret from .env
app.use(session({
  secret: process.env.SESSION_SECRET || "defaultsecret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production", // true only in production
    httpOnly: true,
    sameSite: "none",
    maxAge: 1000 * 60 * 60 * 24 // 1 day
  }
}));

app.use(passport.initialize());
app.use(passport.session());
app.set("io", io);

// Routes
import userRouter from "./routes/user.routes.js";
import chatRouter from "./routes/chat.routes.js";

app.use("/api/v1/users", userRouter);
app.use("/api/v1/chat", chatRouter);

// Error Handler
import errorHandler from "./middlewares/errorHandler.js";
app.use(errorHandler);

// Start Server
const PORT = process.env.PORT || 10000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
