import prisma from "../prisma.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { deleteOnCloudinary, uploadOnCloudinary } from "../utils/cloudinary.js";

const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, phone, username } = req.body;

  if ([name, email, password, phone, username].some((field) => field?.trim() === "")) {
    throw new ApiError(400, "All fields are required");
  }

  const existedUser = await prisma.user.findFirst({
    where: { email }
  });

  if (existedUser) {
    throw new ApiError(409, "User with email or phone already exist");
  }

  let profileUrl = null;
  let publicId = null;
  if (req.file) {
    const uploadedImage = await uploadOnCloudinary(req.file.path, "users");
    profileUrl = uploadedImage?.secure_url || "";
    publicId = uploadedImage?.public_id;
  }

  // Hash the password before storing it
  const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds

  const user = await prisma.user.create({
    data: {
      email,
      password: hashedPassword,
      username: username,  
    },
    select: {
      id: true,
      username: true,
      email: true,
      createdAt: true,
      role: true
    }
  });


  //send email
  // await sendEmail({
  //   to: user.email,
  //   subject: `Welcome, Twycer`,
  //   template: "welcome",
  //   data: {
  //     name: user.fullName,
  //     dashboardUrl: websiteUrl,
  //     logoUrl: logoUrl,
  //   },
  // });

  return res
    .status(201)
    .json(new ApiResponse(201, user, "User Registered Successfully"));
});

const loginUser = asyncHandler(async (req, res) => {
  const { email, phone, password } = req.body;


  if (!(email || phone)) {
    throw new ApiError(400, "Email or phone is required");
  }

  if (!password) {
    throw new ApiError(400, "Password is required");
  }

  //  Find user by email or phone
  const user = await prisma.user.findFirst({
    where: {
      OR: [{ email: email || undefined }, { phone: phone || undefined }],
    }

  });

  if (!user) {
    throw new ApiError(404, "User does not exist");
  }

  //  Compare hashed password
  const isPasswordValid = await bcrypt.compare(password, user.password);

  if (!isPasswordValid) {
    throw new ApiError(401, "Incorrect Password");
  }

  //  Generate JWT token
  const accessToken = jwt.sign(
    { id: user.id }, // Use Prisma `id`
    process.env.ACCESS_TOKEN_SECRET,
    { expiresIn: process.env.ACCESS_TOKEN_EXPIRY }
  );

  //  Remove password before sending response
  const { password: _, ...loggedInUser } = user;

  //  Cookie options
  const options = {
    httpOnly: true,
    secure: true,
    sameSite: "none",
  };
  //send vendorId in user object
  // if (!user.vendorId) {
  //   const vendor = await prisma.vendor.findUnique({
  //     where: { userId: user.id },
  //     select: { id: true },
  //   });
  //   loggedInUser.vendorId = vendor ? vendor.id : null;
  // }

  return res
    .status(200)
    .cookie("accessToken", accessToken, options)
    .json(
      new ApiResponse(
        200,
        { user: loggedInUser, accessToken },

        "User logged in successfully"
      )
    );
});

const logoutUser = asyncHandler(async (req, res) => {
  // Clear the access token cookie
  res.clearCookie("accessToken", {
    httpOnly: true,
    secure: true,
  });

  return res
    .status(200)
    .json(new ApiResponse(200, null, "User logged out successfully"));
});

const getCurrentUser = asyncHandler(async (req, res) => {
  return res
    .status(200)
    .json(new ApiResponse(200, req.user, "current user fetched successfully"));
});

const getUsers = asyncHandler(async (req, res) => {
  const users = await prisma.user.findMany({
    select: {
      id: true,
      username: true,
      email: true,
      avatarUrl: true,
      publicId: true,
      role: true,
      createdAt: true,
      updatedAt: true,
    },
  });


  res
    .status(200)
    .json(new ApiResponse(200, users, "Users retrieved successfully"));
});

const getUserById = asyncHandler(async (req, res) => {
  const { userId } = req.params;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      role: true,
      createdAt: true,
      profileImage: true,
      addresses: true,
      followers: true,
      following: true,
      products: {
        include: {
          images: true,
        },
      },
    },
  });

  if (!user) {
    throw new ApiError(404, "User not found");
  }

  res
    .status(200)
    .json(new ApiResponse(200, user, "User retrieved successfully"));
});

const deleteUser = asyncHandler(async (req, res) => {
  const { userId } = req.params;

  const user = await prisma.user.findUnique({ where: { id: userId } });

  if (!user) {
    throw new ApiError(404, "User not found");
  }

  await prisma.user.delete({ where: { id: userId } });

  res.status(200).json(new ApiResponse(200, null, "User deleted successfully"));
});

const updateUser = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const { name, phone, gender, password } = req.body;

  if (!name && !phone && !gender && !password) {
    throw new ApiError(400, "No fields provided to update.");
  }

  const updateData = {};
  if (name) updateData.name = name;
  if (phone) updateData.phone = phone;
  if (gender) updateData.gender = gender;
  if (password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    updateData.password = hashedPassword;
  }

  const existedUser = await prisma.user.findUnique({
    where: { id: userId },
  });

  let profileUrl = existedUser?.profileImage;
  let publicId = existedUser?.publicId;

  if (req.file) {
    // Delete the old image from Cloudinary if it exists
    if (existedUser?.publicId) {
      await deleteOnCloudinary(existedUser.publicId);
    }

    // Upload the new image
    const uploadedImage = await uploadOnCloudinary(req.file.path, "users");
    profileUrl = uploadedImage?.secure_url || "";
    publicId = uploadedImage?.public_id;
  }

  const updatedUser = await prisma.user.update({
    where: { id: userId },
    data: {
      ...updateData,
      profileImage: profileUrl,
      publicId: publicId,
    },
  });

  res
    .status(200)
    .json(new ApiResponse(200, updatedUser, "Profile updated successfully"));
});

const sendSignupOTP = asyncHandler(async (req, res) => {
  const { email, phone } = req.body;

  if (!email) throw new ApiError(400, "Email is required");

  const existedUser = await prisma.user.findFirst({
    where: {
      OR: [{ email }, { phone }],
    },
  });
  if (existedUser) throw new ApiError(409, "Email or Phone already in use");

  const otp = Math.floor(1000 + Math.random() * 9000).toString(); // 4-digit OTP
  const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

  await prisma.tempOTP.upsert({
    where: { email },
    update: { otp, otpExpiry },
    create: { email, otp, otpExpiry },
  });

  try {
    // await sendEmail({
    //   to: email,
    //   subject: "Signup OTP",
    //   template: "emailVerification",
    //   data: { otp, name: req.body.name, logoUrl },
    // });
    // re-use existing email sender
    return res
      .status(200)
      .json(new ApiResponse(200, null, "OTP sent to email"));
  } catch (error) {
    console.error("Error sending OTP:", error);
    throw new ApiError(500, "Failed to send OTP");
  }
});

const verifySignupOTP = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;

  if (!email || !otp) throw new ApiError(400, "Email and OTP required");

  const record = await prisma.tempOTP.findUnique({ where: { email } });

  if (!record || record.otp !== otp || new Date() > record.otpExpiry) {
    throw new ApiError(401, "Invalid or expired OTP");
  }

  // Optional: delete OTP after verification
  await prisma.tempOTP.delete({ where: { email } });

  return res.status(200).json(new ApiResponse(200, null, "OTP verified"));
});

// reset password using ndemailer with otp
const sendResetPasswordOTP = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) throw new ApiError(400, "Email is required");

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new ApiError(404, "User not found");

  const otp = Math.floor(1000 + Math.random() * 9000).toString(); // 4-digit OTP
  const otpExpiry = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes expiry

  await prisma.tempOTP.upsert({
    where: { email },
    update: { otp, otpExpiry },
    create: { email, otp, otpExpiry },
  });
  try {
    // await sendEmail({
    //   to: email,
    //   subject: "Reset Password OTP",
    //   template: "emailVerification",
    //   data: { otp },
    // });
  } catch (error) {
    console.error("Error sending OTP:", error);
    throw new ApiError(500, "Failed to send OTP");
  }
  return res.status(200).json(new ApiResponse(200, null, "OTP sent to email"));
});

const verifyResetPasswordOTP = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) throw new ApiError(400, "Email and OTP are required");
  const record = await prisma.tempOTP.findUnique({ where: { email } });

  if (!record || record.otp !== otp || new Date() > record.otpExpiry) {
    throw new ApiError(401, "Invalid or expired OTP");
  }

  // Optional: delete OTP after verification
  await prisma.tempOTP.delete({ where: { email } });
  return res.status(200).json(new ApiResponse(200, null, "OTP verified"));
});

const resetPassward = asyncHandler(async (req, res) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword)
    throw new ApiError(400, "Email and new password are required");
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new ApiError(404, "User not found");
  // Hash the new password
  const hashedPassword = await bcrypt.hash(newPassword, 10);

  // Update the user's password
  await prisma.user.update({
    where: { email },
    data: { password: hashedPassword },
  });

  return res
    .status(200)
    .json(new ApiResponse(200, null, "Password reset successfully"));
});

export {
  registerUser,
  loginUser,
  logoutUser,
  getCurrentUser,
  getUsers,
  getUserById,
  deleteUser,
  updateUser,
  sendSignupOTP,
  verifySignupOTP,
  sendResetPasswordOTP,
  verifyResetPasswordOTP,
  resetPassward,
};
