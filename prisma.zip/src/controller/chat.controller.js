import prisma from "../prisma.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const createRoom = asyncHandler(async (req, res) => {
    const { name, isGroup, memberIds } = req.body;

    // Input validation
    if (!memberIds || !Array.isArray(memberIds) || memberIds.length === 0) {
        throw new ApiError(400, "Member IDs are required");
    }

    if (isGroup && (!name || name.trim().length === 0)) {
        throw new ApiError(400, "Group name is required");
    }

    // Deduplicate and include creator
    const allMembers = [...new Set([...memberIds, req.user.id])];

    // Validate member existence
    const existingUsers = await prisma.user.findMany({
        where: { id: { in: allMembers } },
        select: { id: true }
    });

    const existingUserIds = existingUsers.map(user => user.id);
    const nonExistingUsers = allMembers.filter(id => !existingUserIds.includes(id));

    if (nonExistingUsers.length > 0) {
        throw new ApiError(400, `Users not found: ${nonExistingUsers.join(', ')}`);
    }



    if (isGroup && allMembers.length < 2) {
        throw new ApiError(400, "Group chat requires at least 2 members");
    }

    // 1-to-1 chat check (fixed logic)
    if (!isGroup) {
        const existingRoom = await prisma.chatRoom.findFirst({
            where: {
                isGroup: true,
                AND: allMembers.map(userId => ({
                    members: {
                        some: { userId: userId }
                    }
                }))
            },
            include: {
                members: {
                    include: { user: true }
                }
            },
        });

        if (existingRoom) {
            return res
                .status(200)
                .json(new ApiResponse(200, existingRoom, "1-to-1 chat already exists"));
        }
    }

    // Create room and members in transaction
    const room = await prisma.$transaction(async (tx) => {
        const newRoom = await tx.chatRoom.create({
            data: {
                name: isGroup ? name.trim() : null,
                isGroup: isGroup || false,
                // Removed createdBy field since it doesn't exist in your schema
            },
        });

        await tx.chatMember.createMany({
            data: allMembers.map(id => ({
                userId: id,
                roomId: newRoom.id,
                joinedAt: new Date(),
                role: id === req.user.id ? 'ADMIN' : 'MEMBER'
            })),
        });
 
        // Create welcome message for group
        if (isGroup) {
            await tx.message.create({
                data: {
                    content: `Group created by ${req.user.username}`,
                    roomId: newRoom.id,
                    senderId: req.user.id,
                    type: 'SYSTEM',
                    statuses: {
                        create: allMembers.map(userId => ({
                            userId: userId,
                            status: 'SENT'
                        }))
                    }
                }
            });
        }

        return await tx.chatRoom.findUnique({
            where: { id: newRoom.id },
            include: {
                members: {
                    include: { user: true }
                },
                messages: {
                    take: 1,
                    orderBy: { createdAt: 'desc' },
                    include: { sender: true }
                }
            }
        });
    });

    // Emit real-time event for new room creation
    const io = req.app.get("io");
    if (io) {
        allMembers.forEach(userId => {
            io.to(userId).emit('room-created', room);
        });
    }

    return res
        .status(201)
        .json(new ApiResponse(201, room, "Chat room created successfully"));
});

// Get all rooms for current user with pagination
const getMyRooms = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const [rooms, totalCount] = await Promise.all([
        prisma.chatMember.findMany({
            where: { userId: req.user.id },
            include: {
                room: {
                    include: {
                        members: {
                            include: { user: true },
                            orderBy: { joinedAt: 'asc' }
                        },
                        messages: {
                            take: 1,
                            orderBy: { createdAt: 'desc' },
                            include: { sender: true }
                        }
                    },
                },
            },
            orderBy: { room: { updatedAt: 'desc' } },
            skip,
            take: parseInt(limit),
        }),
        prisma.chatMember.count({
            where: { userId: req.user.id }
        })
    ]);

    res.status(200).json(new ApiResponse(200, {
        rooms,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: parseInt(page)
    }, "Rooms fetched successfully"));
});

// Get messages of a room with pagination
const getMessages = asyncHandler(async (req, res) => {
    const { roomId } = req.params;
    const { page = 1, limit = 50, before } = req.query;

    // Check membership
    const membership = await prisma.chatMember.findUnique({
        where: { userId_roomId: { userId: req.user.id, roomId } },
    });

    if (!membership) {
        throw new ApiError(403, "You are not a member of this room");
    }

    // Build where clause for pagination
    const where = { roomId };
    if (before) {
        where.createdAt = { lt: new Date(before) };
    }

    const [messages, totalCount] = await Promise.all([
        prisma.message.findMany({
            where,
            include: {
                sender: true,
                statuses: {
                    where: { userId: req.user.id }
                }
            },
            orderBy: { createdAt: "desc" },
            skip: (page - 1) * limit,
            take: parseInt(limit),
        }),
        prisma.message.count({ where: { roomId } })
    ]);

    // Mark messages as read
    const unreadMessages = messages.filter(msg =>
        !msg.statuses.length || msg.statuses[0].status !== 'READ'
    );

    if (unreadMessages.length > 0) {
        const unreadMessageIds = unreadMessages.map(msg => msg.id);

        // Update existing statuses
        await prisma.messageStatus.updateMany({
            where: {
                messageId: { in: unreadMessageIds },
                userId: req.user.id
            },
            data: {
                status: "READ",
                readAt: new Date()
            },
        });

        // Create statuses for messages that don't have them
        const messagesWithoutStatus = unreadMessages.filter(msg => !msg.statuses.length);
        if (messagesWithoutStatus.length > 0) {
            await prisma.messageStatus.createMany({
                data: messagesWithoutStatus.map(msg => ({
                    messageId: msg.id,
                    userId: req.user.id,
                    status: "READ",
                    readAt: new Date()
                }))
            });
        }

        // Emit read events
        const io = req.app.get("io");
        if (io) {
            io.to(roomId).emit('messages-read', {
                messageIds: unreadMessageIds,
                userId: req.user.id
            });
        }
    }

    res.status(200).json(new ApiResponse(200, {
        messages: messages.reverse(), // Return in chronological order
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: parseInt(page)
    }, "Messages fetched successfully"));
});

// Mark multiple messages as read
const markMessageRead = asyncHandler(async (req, res) => {
    const { messageIds } = req.body;
    const { roomId } = req.params;

    if (!messageIds || !Array.isArray(messageIds)) {
        throw new ApiError(400, "Message IDs array is required");
    }

    // Verify user is member of the room
    const membership = await prisma.chatMember.findUnique({
        where: { userId_roomId: { userId: req.user.id, roomId } },
    });

    if (!membership) {
        throw new ApiError(403, "You are not a member of this room");
    }

    // Update message statuses
    const updatedStatuses = await Promise.all(
        messageIds.map(messageId =>
            prisma.messageStatus.upsert({
                where: {
                    messageId_userId: {
                        messageId,
                        userId: req.user.id
                    }
                },
                update: {
                    status: "READ",
                    readAt: new Date()
                },
                create: {
                    messageId,
                    userId: req.user.id,
                    status: "READ",
                    readAt: new Date()
                }
            })
        )
    );

    // Emit real-time event
    const io = req.app.get("io");
    if (io) {
        io.to(roomId).emit('messages-read', {
            messageIds,
            userId: req.user.id
        });
    }

    res.status(200).json(new ApiResponse(200, updatedStatuses, "Messages marked as read"));
});

// Add members to room (group only)
const addMembersToRoom = asyncHandler(async (req, res) => {
    const { roomId } = req.params;
    const { memberIds } = req.body;

    if (!memberIds || !Array.isArray(memberIds)) {
        throw new ApiError(400, "Member IDs array is required");
    }

    // Check if user is admin of the room
    const userMembership = await prisma.chatMember.findUnique({
        where: { userId_roomId: { userId: req.user.id, roomId } },
    });

    if (!userMembership || userMembership.role !== 'ADMIN') {
        throw new ApiError(403, "Only admins can add members");
    }

    // Check if room is a group
    const room = await prisma.chatRoom.findUnique({
        where: { id: roomId }
    });

    console.log(room);

    if (!room.isGroup) {
        throw new ApiError(400, "Cannot add members to 1-to-1 chat");
    }

    // Add new members
    const newMembers = await Promise.all(
        memberIds.map(userId =>
            prisma.chatMember.upsert({
                where: { userId_roomId: { userId, roomId } },
                update: {}, // Do nothing if already exists
                create: {
                    userId,
                    roomId,
                    joinedAt: new Date(),
                    role: 'MEMBER'
                }
            })
        )
    );

    // Create system message
    const systemMessage = await prisma.message.create({
        data: {
            content: `${newMembers.length} member(s) added by ${req.user.username}`,
            roomId,
            senderId: req.user.id,
            type: 'SYSTEM',
            statuses: {
                create: (await prisma.chatMember.findMany({
                    where: { roomId },
                    select: { userId: true }
                })).map(member => ({
                    userId: member.userId,
                    status: 'SENT'
                }))
            }
        }
    });

    // Emit real-time events
    const io = req.app.get("io");
    if (io) {
        io.to(roomId).emit('members-added', {
            roomId,
            members: newMembers,
            addedBy: req.user.id
        });
    }

    res.status(200).json(new ApiResponse(200, newMembers, "Members added successfully"));
});

// Remove member from room (admin only)
const removeMemberFromRoom = asyncHandler(async (req, res) => {
    const { roomId, userId } = req.params;

    // Check if user is admin
    const userMembership = await prisma.chatMember.findUnique({
        where: { userId_roomId: { userId: req.user.id, roomId } },
    });

    if (!userMembership || userMembership.role !== 'ADMIN') {
        throw new ApiError(403, "Only admins can remove members");
    }

    // Cannot remove yourself
    if (userId === req.user.id) {
        throw new ApiError(400, "Cannot remove yourself from room");
    }

    // Remove member
    await prisma.chatMember.delete({
        where: { userId_roomId: { userId, roomId } }
    });

    // Create system message
    const systemMessage = await prisma.message.create({
        data: {
            content: `Member removed by ${req.user.username}`,
            roomId,
            senderId: req.user.id,
            type: 'SYSTEM',
            statuses: {
                create: (await prisma.chatMember.findMany({
                    where: { roomId },
                    select: { userId: true }
                })).map(member => ({
                    userId: member.userId,
                    status: 'SENT'
                }))
            }
        }
    });

    // Emit real-time events
    const io = req.app.get("io");
    if (io) {
        io.to(roomId).emit('member-removed', {
            roomId,
            userId,
            removedBy: req.user.id
        });

        io.to(userId).emit('room-removed', { roomId });
    }

    res.status(200).json(new ApiResponse(200, null, "Member removed successfully"));
});

// Get room details
const getRoomDetails = asyncHandler(async (req, res) => {
    const { roomId } = req.params;

    // Check membership
    const membership = await prisma.chatMember.findUnique({
        where: { userId_roomId: { userId: req.user.id, roomId } },
    });

    if (!membership) {
        throw new ApiError(403, "You are not a member of this room");
    }

    const room = await prisma.chatRoom.findUnique({
        where: { id: roomId },
        include: {
            members: {
                include: { user: true },
                orderBy: { joinedAt: 'asc' }
            },
            messages: {
                take: 10,
                orderBy: { createdAt: 'desc' },
                include: { sender: true }
            }
        }
    });

    res.status(200).json(new ApiResponse(200, room, "Room details fetched successfully"));
});

export {
    createRoom,
    getMyRooms,
    getMessages,
    markMessageRead,
    addMembersToRoom,
    removeMemberFromRoom,
    getRoomDetails
};